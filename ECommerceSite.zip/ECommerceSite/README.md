## Team 4: eCommerce project
## Teammates: Kavita, Eddie, Ryker, Danitza

**Description**

This is our hosting of the group proyect 4 for ASP.NET core. Our goal is to create a e-commerce website that works alongside 
azure and SQLite. 