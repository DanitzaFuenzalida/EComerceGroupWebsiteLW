/*@page
@model YourNamespace.ShopModel
@{
    ViewData["Title"] = "Shop page";
}

< !DOCTYPE html >
< html >
< head >
    < title > @ViewData["Title"] </ title >
</ head >
< body >
    < div class= "text-center" >
        < h1 class= "display-4" > Shop </ h1 >
        < p > This is the shop page.Display products or search results here.</p>
    </div>
</body>
</html>
*/