﻿using Microsoft.AspNetCore.Mvc;

namespace ECommerceSite.Controller
{
    public class PrivacyController : Microsoft.AspNetCore.Mvc.Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
