﻿namespace ECommerceSite.Model
{
    public class Product
    {
        public int ProductId { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public decimal Price { get; set; }
        public int StockQuantity { get; set; }
        public string Category { get; set; }
        // Add other properties like images, ratings, etc.

        public string Color { get; set; }
    }
}

