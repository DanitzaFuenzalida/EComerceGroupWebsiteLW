﻿using Microsoft.AspNetCore.Mvc.RazorPages;

public class ShopModel : PageModel
{
    public void OnGet()
    {
        // You can add code here to handle the GET request for the Shop page
    }
}